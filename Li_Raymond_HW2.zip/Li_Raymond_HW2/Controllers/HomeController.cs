﻿using Li_Raymond_HW2.Models;
using Microsoft.AspNetCore.Mvc;
using System;
namespace Li_Raymond_HW2.Controllers
{
    public class HomeController : Controller
    {
        const int tacoPrice = 3;
        const int sandwichPrice = 5;
        const decimal tax = 0.085M;

        public ViewResult Index()
        {
            int hour = DateTime.Now.Hour;
            ViewBag.Greeting = hour < 12 ? "Good Morning" : "Good Afternoon";
            return View();
        }
        [HttpPost]
        public ViewResult SubmitOrder(OrderRequest orderRequest)
        {
            if (ModelState.IsValid)
            {
                decimal decTemp = 0.00M;
                ViewBag.CustomerCode = orderRequest.CustomerCode.ToUpper();
                ViewBag.TotalItems = orderRequest.NumberOfSandwiches + orderRequest.NumberOfTacos;
                ViewBag.TacoSubtotal = orderRequest.NumberOfTacos * tacoPrice;
                ViewBag.SandwichSubtotal = orderRequest.NumberOfSandwiches * sandwichPrice;
                ViewBag.Subtotal = ViewBag.TacoSubtotal + ViewBag.SandwichSubtotal;
                decTemp = ViewBag.Subtotal * tax;
                ViewBag.TaxSubtotal = decTemp.ToString("C2");
                ViewBag.GrandTotal = (decTemp + ViewBag.Subtotal).ToString("C2");
                return View();
            }
            else
            {
                return View("Index");
            }  
        }
    }
}