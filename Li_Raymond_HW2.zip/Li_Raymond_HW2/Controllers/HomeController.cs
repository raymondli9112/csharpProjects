﻿using Li_Raymond_HW2.Models;
using Microsoft.AspNetCore.Mvc;
using System;
namespace Li_Raymond_HW2.Controllers
{
    public class HomeController : Controller
    {
        const int tacoPrice = 3;
        const int sandwichPrice = 5;
        const decimal tax = 0.085M;

        public ViewResult Index()
        {          
            return View();
        }
        [HttpPost]
        public ViewResult SubmitOrder(OrderRequest orderRequest)
        {
            if (ModelState.IsValid)
            {
                decimal decTemp = 0.00M;
                ViewBag.CustomerCode = orderRequest.CustomerCode.ToUpper();
                int numOfSandwiches;
                int.TryParse(orderRequest.NumberOfSandwiches, out numOfSandwiches);
                int numOfTacos;
                int.TryParse(orderRequest.NumberOfTacos, out numOfTacos);
                ViewBag.TotalItems = numOfSandwiches + numOfTacos;               
                decimal decTempTaco = numOfTacos * tacoPrice;
                ViewBag.TacoSubtotal = decTempTaco.ToString("C2");
                decimal decTempSandwich = numOfSandwiches * sandwichPrice;
                ViewBag.SandwichSubtotal = decTempSandwich.ToString("C2");
                ViewBag.Subtotal = decTempTaco + decTempSandwich;                
                decTemp = (decTempTaco + decTempSandwich) * tax;
                ViewBag.TaxSubtotal = decTemp.ToString("C2");
                ViewBag.GrandTotal = (decTemp + ViewBag.Subtotal).ToString("C2");
                ViewBag.Subtotal = (decTempTaco + decTempSandwich).ToString("C2");
                return View();
            }
            else
            {
                return View("Index");
            }  
        }
    }
}