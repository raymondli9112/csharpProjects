﻿using System.ComponentModel.DataAnnotations;

namespace Li_Raymond_HW2.Models
{
    public class OrderRequest
    {
        [Required(ErrorMessage = "Customer code must be 2-4 characters.")]
        [RegularExpression("([A-Za-z]){2,4}", ErrorMessage = "Customer code must be 2-4 characters.")]
        public string CustomerCode { get; set; }
        [Required(ErrorMessage = "You must purchase at least one item!")]
        //[RegularExpression(@"^\d+$", ErrorMessage = "is not a valid integer!")]
        public int NumberOfTacos { get; set; }
        public int NumberOfSandwiches { get; set; }
    }
}