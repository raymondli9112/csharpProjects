﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Li_Raymond_HW2.Models
{
    public class RequiredIfNullAttribute : RequiredAttribute
    {
        private String PropertyName { get; set; }
        public RequiredIfNullAttribute(String propertyName)
        {
            PropertyName = propertyName;
        }

        protected override ValidationResult IsValid(object value, ValidationContext context)
        {
            Object instance = context.ObjectInstance;
            Type type = instance.GetType();
            Object proprtyvalue = type.GetProperty(PropertyName).GetValue(instance, null);
            if (proprtyvalue == null || int.Parse(proprtyvalue.ToString()) == 0)
            {
                if (value == null || int.Parse(value.ToString()) == 0)
                    return new ValidationResult(null);

                ValidationResult result = base.IsValid(value, context);
                return result;
            }
            return ValidationResult.Success;
        }
    }
}